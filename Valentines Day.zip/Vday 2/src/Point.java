import java.awt.Color;

public class Point {
	int x, y;
	Color c;
	// finish the constructor for Point that will
	// allow someone to creat a point Object
	


}